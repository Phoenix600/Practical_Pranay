from django.apps import AppConfig


class JobvacancyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'JobVacancy'
